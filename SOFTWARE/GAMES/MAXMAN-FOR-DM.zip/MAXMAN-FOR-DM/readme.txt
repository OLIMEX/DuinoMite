This game was originally written for MaxiMite Basic 3.1 then labels are add to may run on DuinoMite.
Please make sure you have the latest firmware from April 7th or later as in the previous verions PRINT command scroll up and do not allow front page to be display correctly.
